import UIKit

var greeting = "Hello, playground"
2 + 2


//Variables
greeting = "adios"

let constante = "Hola"
//constante = "Adios"
/*
 a
 b
 c
 */

// Entero
var entero = 2
var enteroUno: Int = 3

// Doble
var doble = 2.0
var doble1: Double = 3

//Texto
var texto = "Hola"
var texto1: String = "Hello"

//Boolean
var boolean = true;
var bool1: Bool = false


print(doble1 + 3)


//Numeros
//Signed
//Unsigned

let maxValueInt = Int.max
let minValueinT = Int.min

let maxValueUInt = UInt.max
let minValueUinT = UInt.min

print(0.1 + 0.2)

//Operaciones Aritméticas
1 + 1  //SIEMPRE CUIDADO CON EL ACOMODO DE LAS OPERACIONES
1 - 1
1 * 1
1 / 1

5 > 4   //mayor que
5 < 4   //menor que
5 >= 4  //mayor o igual que
5 <= 4  //menor o igual que
5 == 4  //igual que
5 != 4  //diferente que

let binario = 1010
let binario2 = 0b1010

//String

var myString = "Holi"
var segundoString = " a todos "

//Concatenación de strings/cadenas
myString + segundoString //PROHIBIDO EN TRABAJOS POR DEFICIENCIA DE MEMORIA
myString += segundoString

//Caracter de escape
"holi \(segundoString)"

myString.isEmpty

//NO LO HAGAN
//cadena1.count == 0
" ".count == 0


//Arreglos

var arreglo = ["Pedro", "Juan", "Manuel"]
arreglo[1]
arreglo.append("Grecia")
arreglo.count
arreglo.remove(at: 2)
arreglo.removeLast()

//diccionarios

var diccionario: [String:Int] = [:]
diccionario["Edad"] = 26
diccionario["Edad2"] = 26
diccionario

//Tuplas
var color = ("ff0000", "Rojo")
var alumno = ("Dante Sanchez", 8)
var alumno1 : (String, Int) = ("Dante Sanchez", 8)
var alumno2 = (nombreAlumno: "Dante Sanchez", edadAlumno: 8)

alumno.1
alumno2.nombreAlumno

//Sets
var letters = Set<Character>()
letters.insert("a")
//No añade elementos duplicados
letters.insert("a")
letters

































    




