//: [Previous](@previous)

import Foundation

var animal = "cat"

switch animal {
case "dog", "cat": print("it's a common pet")
case "mouse": print("it's a mouse")
default: break
}

var grade = 9
switch grade {
case ...5: print("Failed")
case 6...9: print("Nice!")
case 9: print("Great!")
case 10...: print("WOW!")
default: break
}

let color = (1, 255, 255)
switch color {
case let (r, g, 255) where r < 255:
    print("max blue, g: \(g), r: \(r)")
case (let r, 255, let b): print("max green")
    
case (255, _, _): print("max red")
    
default: print("random color")
}

//Experimento

var plano = (3.4,0)

switch plano {
case (0,0): print("La coordenada está en el origen")
case (0...5,0...5): print("Está en el cuadrante 1 y está ubicado en \(plano)")
case (-5...0, 0...5): print("Está en el cuadrante 2 y está ubicado en \(plano)")
case (-5...0, -5...0): print("Está en el cuadrante 3 y está ubicado en \(plano)")
case (0...5, -5...0): print("Está en el cuadrante 4 y está ubicado en \(plano)")
default: break
}

switch plano {
case (0, -5...5): print("Está en el eje y")
case (-5...5, 0): print("Está en el eje x")
default: break
}



//: [Next](@next)
