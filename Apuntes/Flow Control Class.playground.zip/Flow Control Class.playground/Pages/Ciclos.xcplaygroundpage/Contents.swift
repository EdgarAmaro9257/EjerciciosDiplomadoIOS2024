//: [Previous](@previous)

import Foundation

for index in 1...5 {
    print(index)
}

let numbers = [1, 3, 5, 7]
for number in numbers {
    print(number)
}

let intervalsUpToLast = stride(from: 0, to: 20, by: 5)
for number in intervalsUpToLast {
    print(number)
}

let intervalsThroughLast = stride(from: 0, through: 20, by: 5)
for number in intervalsThroughLast{
    print(number)
}

let pokemon = ["Fire" : "Charmander",
               "Water" : "Mudkip",
               "Grass" : "Turtwig",
               "Electric" : "Pikachu"]

for(type, name) in pokemon {
    print("I like \(name) which is \(type) type")
}

for poke in pokemon {
    print("I like \(poke.value) which is \(poke.key) type")
}

let names: Set = ["Dean", "Sam", "Bobby", "Ellen"]

var index = 0
for _ in names {
    print(index)
    index += 1
}

for (index, name) in names.enumerated() {
    print("\(name) is number \(index)")
}

for (index, (type, name)) in pokemon.enumerated() {
    print("\(index), \(type) \(name)")
}

for(index, poke) in pokemon.enumerated() {
    print("\(index), \(poke.key) \(poke.value)")
}

for (index, name) in names.enumerated() {
    if index % 2 == 0 {
        print("\(name) is \(index)")
    }
}

for (index, name) in names.enumerated() {
    if index % 2 == 0 {
        continue
    } else {
        print(index)
    }
}

for poke in pokemon where poke.key == "Grass" {
    print(poke.value)
}

let intervalsThroughLas = stride(from: 0, through: 60, by: 15)
for number in intervalsThroughLas{
    print(number)
}

//-------------------------------------------------------------------
//While

//Experimento - Serpientes y escaleras sin funciones

import Foundation

var board = Array(repeating: 0, count: 26)
var diceRoll = 0
var playerPosition = 0

// Escaleras
board[2] = +8
board[5] = 11 // Ejemplo: Si el jugador cae en la casilla 5, subirá a la 17 (escalera)
board[8] = +11 // Ejemplo: Si el jugador cae en la casilla 10, retrocederá a la 2 (serpiente)
//Serpientes
board[15] = -12
board[18] = -11
board[21] = -11
board[23] = -5


while playerPosition < 25 {
    diceRoll = Int.random(in: 1...6)
    playerPosition += diceRoll

    if playerPosition < board.count {
        if board[playerPosition] != 0 {
            print("¡Escalera o serpiente! Avanzas a la casilla \(playerPosition + board[playerPosition]).")
            playerPosition += board[playerPosition]
        } else {
            print("Has sacado un \(diceRoll). Avanzas a la casilla \(playerPosition).")
        }
    } else {
        print("Has sacado un \(diceRoll), pero no avanzas. Sigue intentándolo.")
    }
}

print("¡Felicidades! Has llegado a la casilla 25.")



//Experimento - serpientes y escaleras con funciones
import Foundation

func configureBoard() -> [Int] {
    var board = Array(repeating: 0, count: 26)
    // Escaleras
    board[2] = +8
    board[5] = 11 // Ejemplo: Si el jugador cae en la casilla 5, subirá a la 17 (escalera)
    board[8] = +11 // Ejemplo: Si el jugador cae en la casilla 10, retrocederá a la 2 (serpiente)
    //Serpientes
    board[15] = -12
    board[18] = -11
    board[21] = -11
    board[23] = -5
    return board
}

func rollDice() -> Int {
    return Int.random(in: 1...6)
}

func playGame() {
    var board = configureBoard()
    var diceRoll = 0
    var playerPosition = 0

    while playerPosition < 25 {
        diceRoll = rollDice()
        playerPosition += diceRoll

        if playerPosition < board.count {
            if board[playerPosition] != 0 {
                print("¡Escalera o serpiente! Avanzas a la casilla \(playerPosition + board[playerPosition]).")
                playerPosition += board[playerPosition]
            } else {
                print("Has sacado un \(diceRoll). Avanzas a la casilla \(playerPosition).")
            }
        } else {
            print("Has sacado un \(diceRoll), pero no avanzas. Sigue intentándolo.")
        }
    }

    print("¡Felicidades! Has llegado a la casilla 25.")
}

// Llamamos a la función principal para iniciar el juego
playGame()




















//: [Next](@next)



