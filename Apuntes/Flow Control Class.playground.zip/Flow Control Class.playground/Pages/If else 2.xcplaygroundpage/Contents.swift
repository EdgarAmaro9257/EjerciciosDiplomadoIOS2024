//: [Previous](@previous)

import Foundation

var animal = "dog"

guard animal == "dog" else {fatalError("It's not a dog :c") }


if animal == "dog" {
    
} else {
    fatalError("It's not a dog :c")
}








//: [Next](@next)
