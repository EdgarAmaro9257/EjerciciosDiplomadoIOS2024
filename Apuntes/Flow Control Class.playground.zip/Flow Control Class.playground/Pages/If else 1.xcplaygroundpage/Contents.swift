import Foundation

var animal = "dog"

if animal == "dog" {
    print("It's a 🐶")
}

if animal != "dog" {
    print("it's  another animal")
}

if !(animal == "dog") {
    print("it's another animal")
} else {
    print("it's a 🐶")
}

animal = "parrot"
if animal.count < 4 {
    print("less than 4 letters")
} else {
    print("too many animals ")
}

animal = "cat"
if animal == "dog" || animal == "cat" {
    print("common pet")
} else {
    print("what is it?!")
}


var number = 2
animal = "cat"
if animal == "cat" {
    print("it's a cat!!!")
}else if number == 2{
    print("number 2")
} else {
    print("unrelated")
}

if animal == "cat" {
    print("it's a cat!!!")
}
if number == 2{
    print("number 2")
}

if #available(iOS 16.6, *){
    // sólo para ese iOS +
} else {
    // código para so anterior a 16.6
}

if #unavailable(iOS 16.6){
    // código para so anteior a 16.6
}

number == 2 ? print("number 2") : print("")

if number == 2 {
    print("number 2")
} else {
        print("")
}

var value = number == 2 ? "number 2" : "others"
// incorrecto
// number == 2 ? value = "number 2" : value = "others"

var exampleValue = ""
if number == 2 {
    exampleValue = "number"
} else {
    exampleValue = "others"
}

//Experimento - Solución en grupo
var weather = "nieve"
var time = 3

if weather == "nieve" {
    print("🌨️")
} else if weather == "lluvia" {
    print("🌧️")
}

if time>=7  && time<=18 {
    print("Usa bloqueador")
}else if time>=19 && time<=23 || time >= 0 && time <= 6{
    print("No necesitas bloqueador")
}

//Solución exagerada
var dark = Array(0...6) + Array(19...23)
var light = 7...18

if weather == "nieve" {
    print("🌨️")
} else if weather == "lluvia" {
    print("🌧️")
}

if light ~= time {
    print("Usa bloqueador")
} else  {
    print("no necesitas bloqueador")
}








