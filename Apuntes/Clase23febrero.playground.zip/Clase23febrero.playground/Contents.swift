import Foundation

var cellphone: String = "5556890539"
//var landline: String? = nil
var landline: String? = "444"

if let landline {
    print(landline)
}

if let landline2 = landline {
    print(landline2)
}

//Saca el landline y utilizar su definición
//guard let landline2 = landline else { fatalError() }
//print(landline2)

//landline! //crash

landline = "444"
print(landline ?? "No landline")

landline = nil
print(landline ?? cellphone)
landline != nil ? landline! : cellphone




