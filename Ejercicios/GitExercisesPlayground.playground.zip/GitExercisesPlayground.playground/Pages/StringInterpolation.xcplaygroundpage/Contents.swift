import Foundation

// Create a constant representing Mexico City elevation
var mexicoCity = 2240


// Use string interpolation to print the following message to the console "Mexico City has an elevation of 2240 m"
var cadena = "Mexico City has an elevation of \(mexicoCity) m"
print(cadena)
